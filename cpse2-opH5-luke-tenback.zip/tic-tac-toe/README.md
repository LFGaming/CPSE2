# Tic Tac Toe
---
CPSE2 Herkansing 11/03/2024 - Opdracht 5 - Luke Tenback
This is a BMPK program so you run it with `bmptk-make run`
## How to run?
You can run the text version by compiling the maintext.cpp file, or use the sfml version by running the mainsfml.cpp file.
In the terminal game you get to choose your move, and after you have the option redo the last move by typing Y for yes redo or N for no do not redo.

In the GUI version you can redo the last move by pressing U for undo.